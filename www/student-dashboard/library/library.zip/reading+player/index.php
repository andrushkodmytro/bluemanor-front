<?php 
	$title = "Reading: single page";
	$header = "hasStudentDashboardMenu hideOnSmall";
	include '../../../_components/header.php';
	include 'content.html';
	include '../../../_components/footer.php'
?>