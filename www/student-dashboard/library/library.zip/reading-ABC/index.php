<?php 
	$title = "Reading ABC: single page";
	$header = "hasStudentDashboardMenu";
	include '../../../_components/header.php';
	include 'content.html';
	include '../../../_components/footer.php'
?>