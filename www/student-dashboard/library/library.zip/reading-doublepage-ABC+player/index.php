<?php 
	$title = "Reading ABC: double page";
	$header = "hasStudentDashboardMenu hideOnSmall";
	include '../../../_components/header.php';
	include 'content.html';
	include '../../../_components/footer.php'
?>