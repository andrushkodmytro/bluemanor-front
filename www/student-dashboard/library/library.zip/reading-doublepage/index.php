<?php 
	$title = "Reading: double page";
	$header = "hasStudentDashboardMenu";
	include '../../../_components/header.php';
	include 'content.html';
	include '../../../_components/footer.php'
?>